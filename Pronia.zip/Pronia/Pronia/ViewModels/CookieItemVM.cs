﻿namespace Pronia.ViewModels
{
    public class CookieItemVM
    {
        public int Id { get; set; }
        public int Count { get; set; }
    }
}
