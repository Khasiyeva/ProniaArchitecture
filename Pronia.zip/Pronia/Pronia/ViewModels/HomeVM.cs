﻿using Pronia.Models;

namespace Pronia.ViewModels
{
    public class HomeVM
    {
        public List<Slider> sliders { get; set; }
        public List<Product> products { get; set; }
    }
}
