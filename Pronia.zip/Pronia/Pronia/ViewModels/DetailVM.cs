﻿using Pronia.Models;

namespace Pronia.ViewModels
{
    public class DetailVM
    {
        public List<Product> Products { get; set; }
        public Product Product { get; set; }
    }
}
