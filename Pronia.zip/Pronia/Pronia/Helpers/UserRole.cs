﻿namespace Pronia.Helpers
{
    public enum UserRole
    {
        Admin,
        Moderator,
        Member
    }
}
